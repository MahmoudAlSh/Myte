import 'package:cloud_firestore/cloud_firestore.dart';

class Reward {
  final String userId;
  final String taskId;
  final int points;
  final String title;
  final Timestamp awardedAt;
  final String description;

  Reward({
    required this.userId,
    required this.taskId,
    required this.points,
    required this.title,
    required this.awardedAt,
    required this.description,
  });

  Map<String, dynamic> toMap() {
    return {
      'userId': userId,
      'taskId': taskId,
      'points': points,
      'title': title,
      'awardedAt': awardedAt,
      'description': description,
    };
  }
}
