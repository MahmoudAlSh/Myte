import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class CreateFamilyPage extends StatefulWidget {
  const CreateFamilyPage({super.key});

  @override
  State<CreateFamilyPage> createState() => _CreateFamilyPageState();
}

class _CreateFamilyPageState extends State<CreateFamilyPage> {
  final _nameController = TextEditingController();
  final _descriptionController = TextEditingController();

  final List<String> _types = ['Family', 'Friends', 'Work'];
  String _familyType = 'Family';
  bool _isLoading = false;

  Future<void> _createFamily() async {
    final name = _nameController.text.trim();
    final description = _descriptionController.text.trim();
    final user = FirebaseAuth.instance.currentUser;

    if (name.isEmpty) {
      _showSnackBar('Please enter a group name');
      return;
    }
    if (user == null) {
      _showSnackBar('User not logged in');
      return;
    }

    setState(() => _isLoading = true);

    try {
      final docRef = FirebaseFirestore.instance.collection('groups').doc();

      final groupData = {
        'id': docRef.id,
        'name': name,
        'description': description,
        'type': _familyType,
        'createdAt': FieldValue.serverTimestamp(),
        'createdBy': user.uid,
        'members': [user.uid],
      };

      final groupRef = await FirebaseFirestore.instance
          .collection('groups')
          .add(groupData);

      await groupRef.collection('members').doc(user.uid).set({
        'role': 'admin',
        'joinedAt': FieldValue.serverTimestamp(),
      });

      _showSnackBar('Group created successfully', isSuccess: true);
      Navigator.pop(context);
    } catch (e) {
      debugPrint('Error creating group: $e');
      _showSnackBar('Failed to create group', isSuccess: false);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showSnackBar(String message, {bool isSuccess = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isSuccess ? Colors.green : Colors.red,
      ),
    );
  }

  InputDecoration _inputDecoration(String label) {
    return InputDecoration(
      labelText: label,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Create New Group"),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        elevation: 1,),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _nameController,
              decoration: _inputDecoration("Group Name"),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _descriptionController,
              maxLines: 3,
              decoration: _inputDecoration("Group Description (optional)"),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _familyType,
              items: _types
                  .map((type) =>
                  DropdownMenuItem(value: type, child: Text(type)))
                  .toList(),
              onChanged: (value) => setState(() => _familyType = value!),
              decoration: _inputDecoration("Type").copyWith(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: _isLoading ? null : _createFamily,
                style: ElevatedButton.styleFrom(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: _isLoading
                    ? const SizedBox(
                  height: 20,
                  width: 20,
                  child: CircularProgressIndicator(
                    color: Colors.white,
                    strokeWidth: 2,
                  ),
                )
                    : const Text("Create Group",
                    style: TextStyle(fontSize: 18)),
              ),
            )
          ],
        ),
      ),
    );
  }
}