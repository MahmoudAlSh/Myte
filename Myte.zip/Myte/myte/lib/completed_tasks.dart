// completed_tasks.dart
import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'task_details.dart';

class CompletedTasksPage extends StatefulWidget {
  const CompletedTasksPage({super.key});

  @override
  State<CompletedTasksPage> createState() => _CompletedTasksPageState();
}

class _CompletedTasksPageState extends State<CompletedTasksPage> {
  List<Map<String, dynamic>> allTasks = [];
  StreamSubscription? _taskSubscription;

  @override
  void initState() {
    super.initState();
    _subscribeToCompletedTasks();
  }

  void _subscribeToCompletedTasks() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    _taskSubscription = FirebaseFirestore.instance
        .collection('tasks')
        .where("completed", isEqualTo: true)
        .snapshots()
        .listen((snapshot) {
      final userId = user.uid;
      final tasks = snapshot.docs
          .map((doc) {
            final data = doc.data();
            data['id'] = doc.id;
            return data;
          })
          .where((task) =>
              task['userId'] == userId || task['assignedMember'] == userId)
          .toList();

      final seenIds = <String>{};
      final uniqueTasks =
          tasks.where((task) => seenIds.add(task['id'])).toList();

      uniqueTasks.sort((a, b) {
        final aTime = a['createdAt'];
        final bTime = b['createdAt'];
        if (aTime == null || bTime == null) return 0;
        return bTime.compareTo(aTime);
      });

      if (mounted) {
        setState(() => allTasks = uniqueTasks);
      }
    });
  }

  Future<bool> _confirmDelete(String taskId) async {
    return await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text("Delete Task"),
            content: const Text("Are you sure you want to delete this task?"),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text("Cancel")),
              ElevatedButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: const Text("Delete")),
            ],
          ),
        ) ??
        false;
  }

  String? _formatDate(DateTime? date) {
    if (date == null) return null;
    return DateFormat('MMM dd, yyyy').format(date);
  }

  Color _getPriorityColor(String priority) {
    switch (priority.toLowerCase()) {
      case 'high':
        return Colors.red;
      case 'medium':
        return Colors.orange;
      case 'low':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  void _navigateToDetails(Map<String, dynamic> task) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => TaskDetailsPage(task: task)),
    );
  }

  @override
  void dispose() {
    _taskSubscription?.cancel();
    super.dispose();
  }

  void _navigateToTaskDetails(Map<String, dynamic> task) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => TaskDetailsPage(task: task)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Completed Tasks"),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 1,
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
      body: allTasks.isEmpty
          ? const Center(child: Text("No completed tasks yet."))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: allTasks.length,
              itemBuilder: (_, index) {
                final task = allTasks[index];
                final dueDate = _formatDate(task['dueDate']?.toDate());
                final isFromFamily = task['groupId'] != null;

                return Dismissible(
                  key: Key(task['id']),
                  direction: DismissDirection.endToStart,
                  confirmDismiss: (_) => _confirmDelete(task['id']),
                  onDismissed: (_) async {
                    await FirebaseFirestore.instance
                        .collection('tasks')
                        .doc(task['id'])
                        .delete();
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text('Task deleted'),
                        backgroundColor: Colors.red));
                  },
                  background: Container(
                    alignment: Alignment.centerRight,
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    color: Colors.red,
                    child: const Icon(Icons.delete, color: Colors.white),
                  ),
                  child: InkWell(
                    onTap: () => _navigateToTaskDetails(task),
                    child: Card(
                      elevation: 3,
                      margin: const EdgeInsets.only(bottom: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Icon(
                              isFromFamily
                                  ? Icons.family_restroom
                                  : Icons.task_alt,
                              color: isFromFamily ? Colors.purple : Colors.blue,
                              size: 30,
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    task['title'],
                                    style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  const SizedBox(height: 4),
                                  if (task['description'] != null)
                                    Text(task['description']),
                                  if (dueDate != null)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 4),
                                      child: Row(
                                        children: [
                                          const Icon(Icons.calendar_today,
                                              size: 14, color: Colors.orange),
                                          const SizedBox(width: 4),
                                          Text(
                                            "Due: $dueDate",
                                            style: const TextStyle(
                                              color: Colors.orange,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  if (task['priority'] != null)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 4),
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 8, vertical: 4),
                                        decoration: BoxDecoration(
                                          color:
                                              _getPriorityColor(task['priority']),
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Text(
                                          "Priority: ${task['priority']}",
                                          style: const TextStyle(
                                              color: Colors.white, fontSize: 12),
                                        ),
                                      ),
                                    ),
                                  if (isFromFamily)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 4),
                                      child: Text(
                                        "From: ${task['familyName'] ?? 'Family'}",
                                        style: TextStyle(
                                          fontStyle: FontStyle.italic,
                                          color: Colors.purple.shade700,
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                            Checkbox(
                              value: task['completed'],
                              onChanged: (_) => _confirmAndCompleteTask(task),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
    );
  }

  Future<void> _confirmAndCompleteTask(Map<String, dynamic> task) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Complete Task"),
        content: const Text("Mark this task as in-completed?"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text("Cancel")),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text("Yes, in-complete")),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => task['completed'] = false);
      await _markTaskAsComplete(task);
    }
  }

  Future<void> _markTaskAsComplete(Map<String, dynamic> task) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final taskRef =
        FirebaseFirestore.instance.collection('tasks').doc(task['id']);
    await taskRef.update({'completed': false});

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Task status updated successfully.'),
            backgroundColor: Colors.green),
      );
    }
  }
}
