import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_smart_dialog/flutter_smart_dialog.dart';
import 'package:intl/intl.dart';
import 'package:myte_1/reward.dart';
import 'package:url_launcher/url_launcher.dart';

class TaskDetailsPage extends StatefulWidget {
  final Map<String, dynamic> task;

  const TaskDetailsPage({super.key, required this.task});

  @override
  State<TaskDetailsPage> createState() => _TaskDetailsPageState();
}

class _TaskDetailsPageState extends State<TaskDetailsPage> {
  late TextEditingController _titleController;
  late TextEditingController _descriptionController;
  late TextEditingController _notesController;
  late TextEditingController _locationUrlController;
  late TextEditingController _rewardDescriptionController;

  String? _fileUrl;
  String? _fileExtension;
  DateTime? _dueDate;
  late String _priority;
  late bool _isCompleted;

  PlatformFile? _pickedFile;
  User? currentUser;
  bool isAllowedToMarkComplete = false;
  bool isEditable = false;

  List<Map<String, dynamic>> _groupMembers = [];
  String? _assignedMemberUid;

  @override
  void initState() {
    super.initState();
    currentUser = FirebaseAuth.instance.currentUser;
    _titleController = TextEditingController(text: widget.task['title']);
    _descriptionController =
        TextEditingController(text: widget.task['description'] ?? '');
    _notesController = TextEditingController(text: widget.task['notes'] ?? '');
    _locationUrlController =
        TextEditingController(text: widget.task['shareLocation'] ?? '');
    _rewardDescriptionController =
        TextEditingController(text: widget.task['rewardDescription'] ?? '');
    _fileUrl = widget.task['fileUrl'];
    _fileExtension = widget.task['fileExtension'];
    _dueDate = widget.task['dueDate']?.toDate();
    _priority = widget.task['priority'] ?? 'Medium';
    _isCompleted = widget.task['completed'] ?? false;

    if (widget.task['taskType'] == 'group') {
      _assignedMemberUid = widget.task['assignedMember'];
      _fetchGroupMembers(widget.task['groupId']);
      _checkPermission();
    } else {
      isAllowedToMarkComplete = true;
      isEditable = true;
    }
  }

  Future<void> _fetchGroupMembers(String groupId) async {
    final snapshot = await FirebaseFirestore.instance
        .collection('groups')
        .doc(groupId)
        .collection('members')
        .get();

    List<Map<String, dynamic>> loadedMembers = [];
    for (var doc in snapshot.docs) {
      final uid = doc.id;
      final userDoc =
          await FirebaseFirestore.instance.collection('users').doc(uid).get();
      final userData = userDoc.data();
      if (userData != null) {
        loadedMembers
            .add({'uid': uid, 'name': userData['username'] ?? 'Unknown'});
      }
    }

    setState(() => _groupMembers = loadedMembers);
  }

  Future<void> _checkPermission() async {
    final uid = currentUser?.uid;
    if (uid == null) return;

    if (widget.task['assignedMember'] == uid) {
      setState(() => isAllowedToMarkComplete = true);
    }

    if (widget.task['taskType'] == 'group' && widget.task['groupId'] != null) {
      final doc = await FirebaseFirestore.instance
          .collection('groups')
          .doc(widget.task['groupId'])
          .collection('members')
          .doc(uid)
          .get();

      if (doc.exists && doc.data()?['role'] == 'admin') {
        setState(() {
          isAllowedToMarkComplete = true;
          isEditable = true;
        });
      }
    }
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(withData: true);
    if (result != null && result.files.first.bytes != null) {
      setState(() {
        _pickedFile = result.files.first;
        _fileUrl = null;
      });
    }
  }

  String _formatDate(DateTime date) => DateFormat('MMM dd, yyyy').format(date);

  Future<void> _saveTask() async {
    SmartDialog.showLoading();
    try {
      if (_pickedFile != null) {
        final user = FirebaseAuth.instance.currentUser;
        if (user == null) return;
        final ref = FirebaseStorage.instance.ref(
          'task_files/${user.uid}/${DateTime.now().millisecondsSinceEpoch}_${_pickedFile!.name}',
        );
        await ref.putData(_pickedFile!.bytes!);
        _fileUrl = await ref.getDownloadURL();
        _fileExtension = _pickedFile!.extension;
      }

      final updatedTask = {
        'title': _titleController.text.trim(),
        'description': _descriptionController.text.trim(),
        'dueDate': _dueDate,
        'priority': _priority,
        'completed': _isCompleted,
        'notes': _notesController.text.trim(),
        'lastUpdated': FieldValue.serverTimestamp(),
      };

      if (widget.task['hasReward'] == true) {
        updatedTask['rewardDescription'] =
            _rewardDescriptionController.text.trim();
      }

      if (_assignedMemberUid != null) {
        updatedTask['assignedMember'] = _assignedMemberUid;
      }

      if (widget.task['taskType'] == 'group') {
        updatedTask['shareLocation'] = _locationUrlController.text.trim();
      }

      if (_fileUrl != null) {
        updatedTask['fileUrl'] = _fileUrl;
        updatedTask['fileExtension'] = _fileExtension;
      }

      await FirebaseFirestore.instance
          .collection('tasks')
          .doc(widget.task['id'])
          .update(updatedTask);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Task updated successfully'),
            backgroundColor: Colors.green),
      );

      Navigator.pop(context, {...widget.task, ...updatedTask});
    } catch (e) {
      debugPrint("Update failed: $e");
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Failed to update task'),
              backgroundColor: Colors.red),
        );
      }
    } finally {
      SmartDialog.dismiss();
    }
  }

  Future<void> _launchFileUrl(String url) async {
    final uri = Uri.tryParse(url);
    if (uri != null && await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Could not open file'), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> markTaskAsComplete(Map<String, dynamic> task) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    await FirebaseFirestore.instance
        .collection('tasks')
        .doc(task['id'])
        .update({'completed': task['completed']});

    if (task['hasReward'] == true && task['assignedMember'] == uid) {
      final reward = Reward(
          userId: uid,
          taskId: task['id'],
          points: 10,
          title: 'Completed "${task['title']}"',
          awardedAt: Timestamp.now(),
          description: task['rewardDescription']);

      await FirebaseFirestore.instance
          .collection('rewards')
          .add(reward.toMap());

      if (!mounted) return;
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text("🎉 Congrats!"),
          content: Text(
              "You got ${task['rewardDescription'] ?? ''} for completing this task!"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Awesome!"),
            )
          ],
        ),
      );
    }
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _notesController.dispose();
    _rewardDescriptionController.dispose();
    _locationUrlController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        title: const Text('Task Details'),
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        actions: isEditable
            ? [
                TextButton(
                  onPressed: _saveTask,
                  child: const Text('Update Task',
                      style: TextStyle(fontWeight: FontWeight.w600)),
                ),
                const SizedBox(width: 12),
              ]
            : null,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (isAllowedToMarkComplete)
              CheckboxListTile(
                value: _isCompleted,
                onChanged: (value) async {
                  setState(() {
                    _isCompleted = value ?? false;
                    widget.task['completed'] = _isCompleted;
                  });
                  try {
                    await markTaskAsComplete(widget.task);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text("Task marked as completed."),
                          backgroundColor: Colors.green),
                    );
                  } catch (_) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text("Failed to update task."),
                          backgroundColor: Colors.red),
                    );
                  }
                },
                title: const Text('Mark as completed'),
                contentPadding: EdgeInsets.zero,
              ),
            const SizedBox(height: 16),
            _buildTextField(_titleController, "Title"),
            _buildTextField(_descriptionController, "Description", maxLines: 3),
            _buildDueDatePicker(),
            _buildPrioritySelector(),
            _buildTextField(_notesController, "Notes", maxLines: 3),
            if (widget.task['taskType'] == 'group') ...[
              _buildTextField(_locationUrlController, "Shared Location (URL)"),
              if (widget.task['hasReward'] == true)
                _buildTextField(
                    _rewardDescriptionController, "Reward Description",
                    maxLines: 2),
              _buildMemberDropdown(),
            ],
            if (_fileUrl != null || _pickedFile != null) _buildFileSection(),
            const SizedBox(height: 32),
            if (widget.task['createdAt'] != null)
              Text("Created: ${_formatDate(widget.task['createdAt'].toDate())}",
                  style: const TextStyle(color: Colors.grey)),
            SizedBox(
              height: 16,
            ),
            if (widget.task['lastUpdated'] != null)
              Text(
                  "Last Updated: ${_formatDate(widget.task['lastUpdated'].toDate())}",
                  style: const TextStyle(color: Colors.grey)),
            SizedBox(
              height: 16,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label,
      {int maxLines = 1}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextField(
        controller: controller,
        enabled: isEditable,
        decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder(),
        ),
        maxLines: maxLines,
      ),
    );
  }

  Widget _buildDueDatePicker() {
    return Row(
      children: [
        const Text('Due Date:'),
        const SizedBox(width: 8),
        TextButton(
          onPressed: isEditable ? () => _selectDate(context) : null,
          child:
              Text(_dueDate != null ? _formatDate(_dueDate!) : 'Select Date'),
        ),
        if (isEditable)
          IconButton(
            onPressed: () => _selectDate(context),
            icon: Icon(Icons.edit, color: Theme.of(context).primaryColor),
          ),
      ],
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _dueDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );

    if (picked != null && picked != _dueDate) {
      setState(() {
        _dueDate = picked;
      });
    }
  }

  Widget _buildPrioritySelector() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: DropdownButtonFormField<String>(
        value: _priority,
        decoration: const InputDecoration(
            labelText: "Priority", border: OutlineInputBorder()),
        isExpanded: true,
        onChanged:
            isEditable ? (value) => setState(() => _priority = value!) : null,
        items: ['Low', 'Medium', 'High']
            .map((level) => DropdownMenuItem(value: level, child: Text(level)))
            .toList(),
      ),
    );
  }

  Widget _buildMemberDropdown() {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: DropdownButtonFormField<String>(
        value: _assignedMemberUid,
        decoration: const InputDecoration(
          labelText: "Assign To",
          border: OutlineInputBorder(),
        ),
        items: _groupMembers
            .map((m) => DropdownMenuItem<String>(
                  value: m['uid'] as String,
                  child: Text(m['name'] as String),
                ))
            .toList(),
        onChanged: isEditable
            ? (value) => setState(() => _assignedMemberUid = value)
            : null,
      ),
    );
  }

  Widget _buildFileSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Attached File:'),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: _fileUrl != null
                  ? GestureDetector(
                      onTap: () => _launchFileUrl(_fileUrl!),
                      child: Text('View File',
                          style: TextStyle(
                            color: Theme.of(context).primaryColor,
                            decoration: TextDecoration.underline,
                            fontWeight: FontWeight.w600,
                          )),
                    )
                  : Text(_pickedFile?.name ?? '',
                      style: const TextStyle(fontWeight: FontWeight.w500)),
            ),
            if (isEditable)
              TextButton.icon(
                onPressed: _pickFile,
                icon: const Icon(Icons.attach_file),
                label: const Text('Replace File'),
              ),
          ],
        ),
      ],
    );
  }
}
