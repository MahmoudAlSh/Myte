import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});

  @override
  State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  final user = FirebaseAuth.instance.currentUser;
  late StreamSubscription<QuerySnapshot> _subscription;
  List<QueryDocumentSnapshot> _notifications = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    if (user != null) _listenToNotifications();
  }

  void _listenToNotifications() {
    _subscription = FirebaseFirestore.instance
        .collection('notifications')
        .where('receiverId', isEqualTo: user!.uid)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .listen((snapshot) {
      setState(() {
        _notifications = snapshot.docs;
        _isLoading = false;
      });
    });
  }

  Future<void> _clearAll() async {
    for (var doc in _notifications) {
      await doc.reference.delete();
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("All notifications cleared")),
      );
    }
  }

  @override
  void dispose() {
    _subscription.cancel();
    super.dispose();
  }

  AppBar _buildAppBar() {
    return AppBar(
      title: const Text("Notifications", style: TextStyle(color: Colors.black)),
      backgroundColor: Colors.white,
      elevation: 1,
      centerTitle: true,
      automaticallyImplyLeading: false,
      iconTheme: const IconThemeData(color: Colors.black),
      actions: [
        if (_notifications.isNotEmpty)
          IconButton(
            icon: const Icon(Icons.clear_all),
            tooltip: "Clear All",
            onPressed: _clearAll,
          ),
      ],
    );
  }

  Future<Map<String, String>> _fetchGroupAndSender(Map<String, dynamic> data) async {
    final group = await FirebaseFirestore.instance
        .collection('groups')
        .doc(data['groupId'])
        .get();

    final sender = await FirebaseFirestore.instance
        .collection('users')
        .doc(data['senderId'])
        .get();

    return {
      'groupName': group.exists ? (group['name'] ?? 'a group') : 'a group',
      'senderName': sender.exists ? (sender['username'] ?? 'Someone') : 'Someone',
    };
  }

  Widget _buildNotificationTile(QueryDocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;

    return FutureBuilder<Map<String, String>>(
      future: _fetchGroupAndSender(data),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final sender = snapshot.data!['senderName'];
        final group = snapshot.data!['groupName'];

        return Card(
          elevation: 2,
          margin: const EdgeInsets.only(bottom: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: ListTile(
            leading: const Icon(Icons.notifications_active, color: Colors.orange),
            title: Text("$sender invited you to join $group"),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.check, color: Colors.green),
                  onPressed: () async {
                    final groupRef = FirebaseFirestore.instance
                        .collection('groups')
                        .doc(data['groupId']);

                    await FirebaseFirestore.instance.runTransaction((transaction) async {
                      transaction.set(
                        groupRef.collection('members').doc(user!.uid),
                        {
                          'role': 'member',
                          'joinedAt': FieldValue.serverTimestamp(),
                        },
                      );

                      transaction.update(groupRef, {
                        'members': FieldValue.arrayUnion([user!.uid]),
                      });
                    });

                    await doc.reference.delete();
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Joined group successfully")),
                      );
                    }
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.red),
                  onPressed: () async {
                    await doc.reference.delete();
                    if (mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Invitation declined")),
                      );
                    }
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (user == null) return const Scaffold(body: SizedBox());

    return Scaffold(
      appBar: _buildAppBar(),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _notifications.isEmpty
          ? const Center(child: Text("No notifications yet."))
          : ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _notifications.length,
        itemBuilder: (context, index) {
          return _buildNotificationTile(_notifications[index]);
        },
      ),
    );
  }
}
