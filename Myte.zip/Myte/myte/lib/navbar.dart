import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'mytasks.dart';
import 'myfamilies.dart';
import 'notifications.dart';
import 'rewards.dart';
import 'settings.dart';
import 'login.dart';

class Navbar extends StatefulWidget {
  const Navbar({super.key});

  @override
  State<Navbar> createState() => _NavbarState();
}

class _NavbarState extends State<Navbar> {
  int _currentIndex = 0;
  final myTasksKey = GlobalKey<MyTasksPageState>();

  void _handleLogout() async {
    await FirebaseAuth.instance.signOut();
    if (!mounted) return;
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LoginPage()),
    );
  }

  List<Widget> get _pages => [
    MyTasksPage(key: myTasksKey),
    MyFamiliesPage(),
    const NotificationsPage(),
    RewardsPage(),
    SettingsPage(onLogout: _handleLogout),
  ];

  List<IconData> get _icons => [
    Icons.task_alt,
    Icons.family_restroom,
    Icons.notifications,
    Icons.emoji_events,
    Icons.settings,
  ];

  List<String> get _labels => [
    "MyTasks",
    "MyGroups",
    "Notifications",
    "Rewards",
    "Settings",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: _pages,
      ),
      bottomNavigationBar: _buildBottomNavigationBar(),
    );
  }

  Widget _buildBottomNavigationBar() {
    return BottomNavigationBar(
      currentIndex: _currentIndex,
      selectedItemColor: Colors.purple,
      unselectedItemColor: Colors.grey,
      onTap: (index) => setState(() => _currentIndex = index),
      type: BottomNavigationBarType.fixed,
      items: List.generate(_icons.length, (index) {
        return BottomNavigationBarItem(
          icon: Icon(_icons[index]),
          label: _labels[index],
        );
      }),
    );
  }
}