import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:myte_1/completed_tasks.dart';
import 'package:myte_1/reward.dart';
import 'create_task.dart';
import 'task_details.dart';

class MyTasksPage extends StatefulWidget {
  const MyTasksPage({super.key});

  @override
  State<MyTasksPage> createState() => MyTasksPageState();
}

class MyTasksPageState extends State<MyTasksPage> {
  List<Map<String, dynamic>> allTasks = [];
  StreamSubscription? _taskSubscription;

  @override
  void initState() {
    super.initState();
    _subscribeToTasks();
  }
//fetch uncompleted tasks from database
  void _subscribeToTasks() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final taskCollection = FirebaseFirestore.instance
        .collection('tasks')
        .where("completed", isEqualTo: false);

    _taskSubscription = taskCollection.snapshots().listen((snapshot) {
      final userId = user.uid;

      final tasks = snapshot.docs
          .map((doc) => {...doc.data(), 'id': doc.id})
          .where((task) =>
              task['userId'] == userId || task['assignedMember'] == userId)
          .toList();

      final seen = <String>{};
      final uniqueTasks = tasks.where((task) => seen.add(task['id'])).toList();

      uniqueTasks.sort((a, b) {
        final aTime = a['createdAt'];
        final bTime = b['createdAt'];
        return (bTime != null && aTime != null) ? bTime.compareTo(aTime) : 0;
      });

      if (mounted) {
        setState(() => allTasks = uniqueTasks);
      }
    });
  }

  @override
  void dispose() {
    _taskSubscription?.cancel();
    super.dispose();
  }

  void _navigateToCreateTask() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => CreateTaskPage(forFamily: false)),
    );
  }

  void _navigateToTaskDetails(Map<String, dynamic> task) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => TaskDetailsPage(task: task)),
    );
  }

  String? _formatDueDate(DateTime? date) {
    if (date == null) return null;
    return DateFormat('MMM dd, yyyy').format(date);
  }

  Future<bool?> _confirmDeleteDialog() {
    return showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Delete Task'),
        content: const Text('Are you sure you want to delete this task?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel')),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Delete')),
        ],
      ),
    );
  }

  Future<void> _deleteTask(String taskId) async {
    await FirebaseFirestore.instance.collection('tasks').doc(taskId).delete();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Task deleted'), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> _confirmAndCompleteTask(Map<String, dynamic> task) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Complete Task"),
        content: const Text("Mark this task as completed?"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text("Cancel")),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text("Yes, complete")),
        ],
      ),
    );

    if (confirmed == true) {
      setState(() => task['completed'] = true);
      await _markTaskAsComplete(task);
    }
  }

  Future<void> _markTaskAsComplete(Map<String, dynamic> task) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final taskRef =
        FirebaseFirestore.instance.collection('tasks').doc(task['id']);
    await taskRef.update({'completed': true});

    if (task['hasReward'] == true && task['assignedMember'] == uid) {
      final reward = Reward(
          userId: uid,
          taskId: task['id'],
          points: 10,
          title: 'Completed "${task['title']}"',
          awardedAt: Timestamp.now(),
          description: task['rewardDescription']);

      await FirebaseFirestore.instance
          .collection('rewards')
          .add(reward.toMap());

      if (mounted) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text("🎉 Congrats!"),
            content: Text(
                "You got ${task['rewardDescription'] ?? ''} for completing this task!"),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text("Awesome!"))
            ],
          ),
        );
      }
    }

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Task status updated successfully.'),
            backgroundColor: Colors.green),
      );
    }
  }

  Color _getPriorityColor(String priority) {
    switch (priority.toLowerCase()) {
      case 'high':
        return Colors.red;
      case 'medium':
        return Colors.orange;
      case 'low':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  Widget _buildTaskCard(Map<String, dynamic> task) {
    final isFromFamily = task['groupId'] != null;
    final dueDate = _formatDueDate(task['dueDate']?.toDate());

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 3,
      child: Dismissible(
        key: Key(task['id']),
        direction: DismissDirection.endToStart,
        background: Container(
          color: Colors.red,
          alignment: Alignment.centerRight,
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: const Icon(Icons.delete, color: Colors.white),
        ),
        confirmDismiss: (_) async {
          final confirmed = await _confirmDeleteDialog();
          if (confirmed == true) {
            await _deleteTask(task['id']);
            return true;
          }
          return false;
        },
        child: InkWell(
          onTap: () => _navigateToTaskDetails(task),
          child: Padding(
            padding: const EdgeInsets.all(12.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(isFromFamily ? Icons.family_restroom : Icons.task_alt,
                    color: isFromFamily ? Colors.purple : Colors.blue,
                    size: 30),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(task['title'],
                          style: const TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      if (task['description'] != null)
                        Text(task['description']),
                      if (dueDate != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Row(
                            children: [
                              const Icon(Icons.calendar_today,
                                  size: 14, color: Colors.orange),
                              const SizedBox(width: 4),
                              Text("Due: $dueDate",
                                  style: const TextStyle(color: Colors.orange)),
                            ],
                          ),
                        ),
                      if (isFromFamily)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text("From: ${task['familyName'] ?? 'Family'}",
                              style: TextStyle(
                                  color: Colors.purple.shade700,
                                  fontStyle: FontStyle.italic)),
                        ),
                      if (task['priority'] != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: _getPriorityColor(task['priority']),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              "Priority: ${task['priority']}",
                              style: const TextStyle(
                                  color: Colors.white, fontSize: 12),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                Checkbox(
                  value: task['completed'] ?? false,
                  onChanged: (_) => _confirmAndCompleteTask(task),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void addFamilyTask(Map<String, dynamic> task) {
    final index = allTasks.indexWhere((t) =>
        (t['id'] != null && t['id'] == task['id']) ||
        (t['familyId'] == task['familyId'] && t['title'] == task['title']));

    setState(() {
      if (index >= 0) {
        allTasks[index] = task;
      } else {
        allTasks.add(task);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Tasks"),
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 1,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.checklist),
            tooltip: "Show Completed Tasks",
            onPressed: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const CompletedTasksPage()));
            },
          ),
        ],
      ),
      body: allTasks.isEmpty
          ? const Center(child: Text("You have no tasks yet."))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: allTasks.length,
              itemBuilder: (context, index) => _buildTaskCard(allTasks[index]),
            ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.purple,
        heroTag: "create_my_task_button",
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        onPressed: _navigateToCreateTask,
        child: const Icon(Icons.add),
      ),
    );
  }
}
