import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class CreateTaskPage extends StatefulWidget {
  final String? familyId;
  final String? familyName;
  final bool forFamily;
  final List<Map<String, dynamic>>? members;

  const CreateTaskPage({
    super.key,
    this.familyId,
    this.familyName,
    required this.forFamily,
    this.members,
  });

  @override
  State<CreateTaskPage> createState() => _CreateTaskPageState();
}

class _CreateTaskPageState extends State<CreateTaskPage> {
  final _formKey = GlobalKey<FormState>();

  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _shareLocationController = TextEditingController();
  final _notesController = TextEditingController();
  final _rewardDescriptionController = TextEditingController();
  final _dueDateController = TextEditingController();

  DateTime? _selectedDueDate;
  bool _hasReward = false;
  bool _isLoading = false;

  PlatformFile? _pickedFile;
  String? _uploadedFileUrl;
  String? _uploadedFileExtension;

  String _priority = 'Medium';
  String? _assignedMemberName;
  String? _assignedMemberUid;

  @override
  void initState() {
    super.initState();
    _dueDateController.text = '';
  }

  Future<void> _pickFile() async {
    final result = await FilePicker.platform.pickFiles(withData: true);
    if (result != null && result.files.isNotEmpty) {
      setState(() => _pickedFile = result.files.first);
    }
  }

  Future<void> _uploadFileToStorage() async {
    if (_pickedFile == null) return;
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final ref = FirebaseStorage.instance.ref(
      'task_files/${user.uid}/${DateTime.now().millisecondsSinceEpoch}_${_pickedFile!.name}',
    );
    final uploadTask = await ref.putData(_pickedFile!.bytes!);
    _uploadedFileUrl = await uploadTask.ref.getDownloadURL();
    _uploadedFileExtension = _pickedFile!.extension;
  }

  Future<void> _selectDueDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDueDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: Colors.purple,
              onPrimary: Colors.white,
              onSurface: Colors.black,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        _selectedDueDate = picked;
        _dueDateController.text = DateFormat('MMM dd, yyyy').format(picked);
      });
    }
  }

  Future<void> _createTask() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);

    await _uploadFileToStorage();
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    final taskData = {
      'title': _titleController.text.trim(),
      'description': _descriptionController.text.trim(),
      'completed': false,
      'createdAt': FieldValue.serverTimestamp(),
      'dueDate': _selectedDueDate,
      'userId': user.uid,
      'notes': _notesController.text.trim(),
      'priority': _priority,
      'taskType': widget.forFamily ? "group" : "personal",
    };

    if (widget.forFamily) {
      taskData.addAll({
        'groupId': widget.familyId,
        'groupName': widget.familyName,
        'hasReward': _hasReward,
        'assignedMember': _assignedMemberUid,
        'shareLocation': _shareLocationController.text.trim(),
      });
      if (_hasReward) {
        taskData['rewardDescription'] =
            _rewardDescriptionController.text.trim();
      }
    }

    if (_uploadedFileUrl != null) {
      taskData.addAll({
        'fileUrl': _uploadedFileUrl,
        'fileExtension': _uploadedFileExtension,
      });
    }

    await FirebaseFirestore.instance.collection('tasks').add(taskData);
    if (!mounted) return;

    setState(() => _isLoading = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("Task Created Successfully!"),
        backgroundColor: Colors.green,
      ),
    );
    Navigator.pop(context);
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _dueDateController.dispose();
    _shareLocationController.dispose();
    _notesController.dispose();
    _rewardDescriptionController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isFamilyTask = widget.familyId != null;
    final pageTitle = isFamilyTask
        ? "Create Task for ${widget.familyName ?? 'Family'}"
        : "Create Personal Task";

    return Scaffold(
      appBar: AppBar(
        title: Text(pageTitle),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        elevation: 1,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              _buildRoundedTextField(_titleController, "Task Title"),
              const SizedBox(height: 12),
              _buildRoundedTextField(
                _descriptionController,
                "Description",
                maxLines: 3,
              ),
              const SizedBox(height: 12),
              GestureDetector(
                onTap: () => _selectDueDate(context),
                child: AbsorbPointer(
                  child: _buildRoundedTextField(
                    _dueDateController,
                    "Due Date",
                    prefixIcon: Icons.calendar_today,
                    isRequired: false,
                  ),
                ),
              ),
              const SizedBox(height: 12),
              TextButton.icon(
                onPressed: _pickFile,
                icon: const Icon(Icons.attach_file),
                label: Text(_pickedFile?.name ?? "Attach File"),
              ),
              if (isFamilyTask) ..._buildFamilyFields(),
              const SizedBox(height: 12),
              _buildRoundedTextField(
                _notesController,
                "Notes (Optional)",
                maxLines: 3,
                isRequired: false,
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _priority,
                decoration: _inputDecoration("Priority"),
                items: ['Low', 'Medium', 'High']
                    .map((level) => DropdownMenuItem(
                  value: level,
                  child: Text(level),
                ))
                    .toList(),
                onChanged: (val) => setState(() => _priority = val ?? 'Medium'),
              ),
              const SizedBox(height: 24),
              SizedBox(
                height: 50,
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _createTask,
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16)),
                  ),
                  child: _isLoading
                      ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    ),
                  )
                      : const Text("Create Task", style: TextStyle(fontSize: 18)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildFamilyFields() {
    return [
      _buildRoundedTextField(
        _shareLocationController,
        "Share Location (URL Optional)",
        prefixIcon: Icons.location_on,
        isRequired: false,
      ),
      _buildSwitchTile("Has Reward?", _hasReward,
              (val) => setState(() => _hasReward = val)),
      if (_hasReward)
        _buildRoundedTextField(_rewardDescriptionController, "Reward Description"),
      if (_hasReward)
        SizedBox(
          height: 12,
        ),
      const SizedBox(height: 12),
      RawAutocomplete<Map<String, dynamic>>(
        optionsBuilder: (textEditingValue) {
          if (textEditingValue.text.isEmpty) return const Iterable.empty();
          return widget.members!.where((member) {
            final name = member['username']?.toLowerCase() ?? '';
            return name.contains(textEditingValue.text.toLowerCase());
          });
        },
        displayStringForOption: (option) => option['username'] ?? '',
        fieldViewBuilder: (context, controller, focusNode, onFieldSubmitted) {
          controller.text = _assignedMemberName ?? '';
          return TextFormField(
            controller: controller,
            focusNode: focusNode,
            decoration: _inputDecoration("Assign to"),
            onFieldSubmitted: (_) => onFieldSubmitted(),
          );
        },
        optionsViewBuilder: (context, onSelected, options) {
          return Material(
            elevation: 4,
            borderRadius: BorderRadius.circular(8),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: options.length,
              itemBuilder: (context, index) {
                final option = options.elementAt(index);
                return ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(option['username'] ?? ''),
                  onTap: () => onSelected(option),
                );
              },
            ),
          );
        },
        onSelected: (member) {
          setState(() {
            _assignedMemberUid = member['uid'];
            _assignedMemberName = member['username'];
          });
        },
      ),
    ];
  }

  Widget _buildRoundedTextField(
      TextEditingController controller,
      String label, {
        int maxLines = 1,
        IconData? prefixIcon,
        bool isRequired = true,
      }) {
    return TextFormField(
      controller: controller,
      maxLines: maxLines,
      decoration: _inputDecoration(label, prefixIcon),
      validator: isRequired
          ? (value) =>
      value == null || value.trim().isEmpty ? "Required" : null
          : null,
    );
  }

  InputDecoration _inputDecoration(String label, [IconData? icon]) {
    return InputDecoration(
      labelText: label,
      prefixIcon: icon != null ? Icon(icon) : null,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: BorderSide(color: Colors.purple.shade200, width: 2),
      ),
    );
  }

  Widget _buildSwitchTile(
      String title,
      bool value,
      void Function(bool) onChanged,
      ) {
    return SwitchListTile(
      title: Text(title),
      value: value,
      onChanged: onChanged,
      activeColor: Colors.purple,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    );
  }
}
