import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class InviteMemberDialog extends StatefulWidget {
  final String groupId;
  final List<String> currentMemberIds;

  const InviteMemberDialog({
    super.key,
    required this.groupId,
    required this.currentMemberIds,
  });

  @override
  State<InviteMemberDialog> createState() => _InviteMemberDialogState();
}

class _InviteMemberDialogState extends State<InviteMemberDialog> {
  final TextEditingController _searchController = TextEditingController();
  List<Map<String, dynamic>> allUsers = [];
  List<Map<String, dynamic>> filteredUsers = [];

  @override
  void initState() {
    super.initState();
    _fetchUsers();
  }

  Future<void> _fetchUsers() async {
    final snapshot = await FirebaseFirestore.instance.collection('users').get();

    final users = snapshot.docs
        .where((doc) => !widget.currentMemberIds.contains(doc.id))
        .map((doc) => {
              'uid': doc.id,
              ...doc.data(),
            })
        .toList();

    setState(() {
      allUsers = users;
      filteredUsers = users;
    });
  }

  void _searchUsers(String query) {
    setState(() {
      filteredUsers = allUsers
          .where((user) => (user['username'] as String)
              .toLowerCase()
              .contains(query.toLowerCase()))
          .toList();
    });
  }

  Future<void> _sendInvite(String receiverId) async {
    final currentUser = FirebaseAuth.instance.currentUser;
    if (currentUser == null) return;

    final inviteDoc =
        FirebaseFirestore.instance.collection('notifications').doc();

    await inviteDoc.set({
      'id': inviteDoc.id,
      'type': 'group_invite',
      'groupId': widget.groupId,
      'receiverId': receiverId,
      'senderId': currentUser.uid,
      'status': 'pending',
      'createdAt': FieldValue.serverTimestamp(),
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Invitation sent'),
        backgroundColor: Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      insetPadding: const EdgeInsets.all(20),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Container(
        constraints: const BoxConstraints(maxHeight: 500),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text("Invite Members",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            TextField(
              controller: _searchController,
              decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: "Search users",
                border: OutlineInputBorder(),
              ),
              onChanged: _searchUsers,
            ),
            const SizedBox(height: 16),
            Expanded(
              child: filteredUsers.isEmpty
                  ? const Center(child: Text("No users found"))
                  : ListView.builder(
                itemCount: filteredUsers.length,
                itemBuilder: (_, index) {
                  final user = filteredUsers[index];
                  final name = user['username'] ?? 'User';
                  final profileImage = user['profileImage'];

                  return ListTile(
                    leading: profileImage != null && profileImage != ""
                        ? CircleAvatar(
                        backgroundImage: NetworkImage(profileImage))
                        : CircleAvatar(
                      backgroundColor: Colors.purple,
                      child: Text(name[0].toUpperCase()),
                    ),
                    title: Text(name),
                    trailing: SizedBox(
                      height: 35,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.purple,
                          padding: const EdgeInsets.symmetric(vertical: 6),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(6),
                          ),
                        ),
                        onPressed: () => _sendInvite(user['uid']),
                        child: const Text("Invite"),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
