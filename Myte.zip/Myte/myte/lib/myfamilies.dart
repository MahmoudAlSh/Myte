import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'create_family.dart';
import 'family_details.dart';

class MyFamiliesPage extends StatefulWidget {
  const MyFamiliesPage({super.key});

  @override
  State<MyFamiliesPage> createState() => _MyFamiliesPageState();
}

class _MyFamiliesPageState extends State<MyFamiliesPage> {
  final user = FirebaseAuth.instance.currentUser;
  late final StreamSubscription<QuerySnapshot> _familyStream;

  List<Map<String, dynamic>> families = [];
  Set<String> _adminGroupIds = {};

  @override
  void initState() {
    super.initState();
    if (user != null) _listenToFamilyGroups();
  }

  @override
  void dispose() {
    _familyStream.cancel();
    super.dispose();
  }

  void _listenToFamilyGroups() {
    _familyStream = FirebaseFirestore.instance
        .collection('groups')
        .where('members', arrayContains: user!.uid)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .listen((snapshot) async {
      final List<Map<String, dynamic>> fetchedFamilies = [];
      final Set<String> adminGroups = {};

      for (final doc in snapshot.docs) {
        final groupData = doc.data();
        groupData['id'] = doc.id;

        final memberDoc = await FirebaseFirestore.instance
            .collection('groups')
            .doc(doc.id)
            .collection('members')
            .doc(user!.uid)
            .get();

        if (memberDoc.data()?['role'] == 'admin') {
          adminGroups.add(doc.id);
        }

        fetchedFamilies.add(groupData);
      }

      if (mounted) {
        setState(() {
          families = fetchedFamilies;
          _adminGroupIds = adminGroups;
        });
      }
    });
  }

  void _navigateToCreateFamily() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const CreateFamilyPage()),
    );
  }

  void _navigateToFamilyDetails(Map<String, dynamic> family) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => FamilyDetailsPage(groupData: family),
      ),
    );
  }

  Future<bool> _confirmGroupDeletion() async {
    return await showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Delete Group"),
        content: const Text("Are you sure you want to delete this group?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Delete"),
          ),
        ],
      ),
    ) ??
        false;
  }

  Future<void> _deleteGroup(String groupId) async {
    await FirebaseFirestore.instance.collection('groups').doc(groupId).delete();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Group deleted"),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Icon(Icons.group_off, size: 64, color: Colors.grey),
          SizedBox(height: 16),
          Text(
            "No Groups yet.",
            style: TextStyle(fontSize: 18, color: Colors.grey),
          ),
        ],
      ),
    );
  }

  Widget _buildFamilyCard(Map<String, dynamic> family, bool isAdmin) {
    final card = Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 3,
      margin: const EdgeInsets.symmetric(vertical: 8),
      child: InkWell(
        onTap: () => _navigateToFamilyDetails(family),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              CircleAvatar(
                backgroundColor: Colors.deepPurple,
                child: Text(
                  family['name'][0].toUpperCase(),
                  style: const TextStyle(color: Colors.white),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      family['name'],
                      style: const TextStyle(fontWeight: FontWeight.bold),
                    ),
                    if (family['description'] != null)
                      Text(family['description']),
                    Text(
                      "Type: ${family['type'] ?? 'Family'}",
                      style: TextStyle(
                        color: Colors.grey.shade700,
                        fontStyle: FontStyle.italic,
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.arrow_forward_ios, size: 18, color: Colors.grey),
            ],
          ),
        ),
      ),
    );

    if (!isAdmin) return card;

    return Dismissible(
      key: Key(family['id']),
      direction: DismissDirection.endToStart,
      background: Container(
        color: Colors.red,
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: const Icon(Icons.delete, color: Colors.white),
      ),
      confirmDismiss: (_) => _confirmGroupDeletion(),
      onDismissed: (_) => _deleteGroup(family['id']),
      child: card,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Groups"),
        automaticallyImplyLeading: false,
        backgroundColor: Colors.white,
        elevation: 1,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.black),
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: families.isEmpty
            ? _buildEmptyState()
            : ListView.builder(
          itemCount: families.length,
          itemBuilder: (context, index) {
            final family = families[index];
            final isAdmin = _adminGroupIds.contains(family['id']);
            return _buildFamilyCard(family, isAdmin);
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToCreateFamily,
        backgroundColor: Colors.purple,
        heroTag: "create_group_button",
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
        child: const Icon(Icons.add),
      ),
    );
  }
}