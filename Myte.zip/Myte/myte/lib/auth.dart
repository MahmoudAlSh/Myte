import 'package:flutter/material.dart';
import 'package:myte_1/animations.dart';
import 'package:myte_1/login.dart';
import 'package:myte_1/signup.dart';

class AuthPage extends StatelessWidget {
  const AuthPage({super.key});

//just for login and signup button and animated logo and welcome text
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildAnimatedLogo(),
              const SizedBox(height: 50),
              _buildWelcomeText(),
              const SizedBox(height: 40),
              _buildLoginButton(context),
              const SizedBox(height: 20),
              _buildSignupButton(context),
            ],
          ),
        ),
      ),
    );
  }

  // ----------------- Private Helper Methods -----------------

  Widget _buildAnimatedLogo() {
    return FadeAnimation(
      duration: const Duration(milliseconds: 800),
      child: Image.asset(
        'assets/logo.png',
        height: 150,
      ),
    );
  }

  Widget _buildWelcomeText() {
    return FadeSlideAnimation(
      duration: const Duration(milliseconds: 800),
      delay: const Duration(milliseconds: 300),
      child: const Text(
        'Welcome to MYTE!',
        style: TextStyle(
          fontSize: 26,
          fontWeight: FontWeight.bold,
          color: Colors.deepPurple,
        ),
      ),
    );
  }

  Widget _buildLoginButton(BuildContext context) {
    return FadeSlideAnimation(
      duration: const Duration(milliseconds: 800),
      delay: const Duration(milliseconds: 600),
      child: SizedBox(
        width: double.infinity,
        child: ElevatedButton(
          onPressed: () {
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const LoginPage()));
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.purple,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
          ),
          child: const Text(
            'Login',
            style: TextStyle(fontSize: 18),
          ),
        ),
      ),
    );
  }

  Widget _buildSignupButton(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (_) => const SignupPage()));
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color.fromARGB(255, 162, 93, 189),
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
        ),
        child: const Text(
          'Sign Up',
          style: TextStyle(fontSize: 18, color: Colors.white),
        ),
      ),
    );
  }
}
