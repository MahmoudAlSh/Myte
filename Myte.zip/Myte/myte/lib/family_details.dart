// family_details_page.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Import for date formatting
import 'package:myte_1/invite_member_dialog.dart';
import 'package:myte_1/reward.dart';
import 'create_task.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
import 'task_details.dart';
import 'package:myte_1/animations.dart';

class FamilyDetailsPage extends StatefulWidget {
  final Map<String, dynamic> groupData;

  const FamilyDetailsPage({
    super.key,
    required this.groupData,
  });

  @override
  State<FamilyDetailsPage> createState() => _FamilyDetailsPageState();
}

class _FamilyDetailsPageState extends State<FamilyDetailsPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<Map<String, dynamic>> members = [];
  List<Map<String, dynamic>> tasks = [];
  String? _userRole;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this)
      ..addListener(() {
        if (mounted) setState(() {});
      });
    _listenToMembers();
    _listenToTasks();
  }

  void _listenToMembers() {
    final user = FirebaseAuth.instance.currentUser;
    if (user == null) return;

    FirebaseFirestore.instance
        .collection('groups')
        .doc(widget.groupData['id'])
        .collection('members')
        .snapshots()
        .listen((snapshot) async {
      List<Map<String, dynamic>> loadedMembers = [];

      for (var doc in snapshot.docs) {
        final uid = doc.id;
        final role = doc.data()['role'] ?? 'member';
        final userDoc =
            await FirebaseFirestore.instance.collection('users').doc(uid).get();
        final userData = userDoc.data() ?? {};

        loadedMembers.add({
          'uid': uid,
          'role': role,
          'username': userData['username'] ?? 'Unknown',
          'profileImage': userData['profileImage'],
        });

        if (uid == user.uid) _userRole = role;
      }

      if (mounted) setState(() => members = loadedMembers);
    });
  }

  void _listenToTasks() {
    FirebaseFirestore.instance
        .collection('tasks')
        .where('groupId', isEqualTo: widget.groupData['id'])
        .snapshots()
        .listen((snapshot) {
      final fetchedTasks =
          snapshot.docs.map((doc) => {'id': doc.id, ...doc.data()}).toList();
      if (mounted) setState(() => tasks = fetchedTasks);
    });
  }

  String? _formatDueDate(Timestamp? timestamp) {
    return timestamp == null
        ? null
        : DateFormat('MMM dd, yyyy').format(timestamp.toDate());
  }

  void _navigateToTaskDetails(Map<String, dynamic> task) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => TaskDetailsPage(task: task)),
    );
  }

  void inviteMember() {
    final memberIds = members.map((e) => e['uid'] as String).toList();
    showDialog(
      context: context,
      builder: (_) => InviteMemberDialog(
        groupId: widget.groupData['id'],
        currentMemberIds: memberIds,
      ),
    );
  }

  void navigateToCreateTask() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CreateTaskPage(
          familyId: widget.groupData['id'],
          familyName: widget.groupData['name'],
          forFamily: true,
          members: members,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        titleTextStyle: const TextStyle(
          color: Colors.black,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
        elevation: 1,
        title: Text(widget.groupData['name']),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [Tab(text: "Tasks"), Tab(text: "Members")],
        ),
      ),
      floatingActionButton: _userRole == 'admin'
          ? FloatingActionButton(
              backgroundColor: Colors.purple,
              onPressed: () {
                if (_tabController.index == 0) {
                  navigateToCreateTask();
                } else {
                  inviteMember();
                }
              },
              child: Icon(
                _tabController.index == 0 ? Icons.add_task : Icons.person_add,
              ),
            )
          : null,
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildTasksTab(),
          _buildMembersTab(),
        ],
      ),
    );
  }

  Widget _buildTasksTab() {
    if (tasks.isEmpty) {
      return const Center(child: Text("No tasks in this group."));
    }
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ListView.builder(
        itemCount: tasks.length,
        itemBuilder: (_, index) {
          final task = tasks[index];
          return _userRole == 'admin'
              ? _buildDismissibleTask(task)
              : buildTaskCard(task);
        },
      ),
    );
  }

  Widget _buildDismissibleTask(Map<String, dynamic> task) {
    return Dismissible(
      key: Key(task['id']),
      direction: DismissDirection.endToStart,
      background: _buildDismissBackground(),
      confirmDismiss: (_) async => await _showConfirmationDialog("Delete Task",
          "Are you sure you want to delete this task?", "Delete"),
      onDismissed: (_) async {
        await FirebaseFirestore.instance
            .collection('tasks')
            .doc(task['id'])
            .delete();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Task deleted'), backgroundColor: Colors.green),
        );
      },
      child: buildTaskCard(task),
    );
  }

  Widget _buildMembersTab() {
    if (members.isEmpty) return const Center(child: Text("No members yet."));
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: ListView.builder(
        itemCount: members.length,
        itemBuilder: (_, index) => _buildMemberItem(index),
      ),
    );
  }

  Widget _buildMemberItem(int index) {
    final member = members[index];
    final isCurrentUser =
        member['uid'] == FirebaseAuth.instance.currentUser?.uid;
    final isGroupCreator = member['uid'] == widget.groupData['createdBy'];

    return _userRole == 'admin' && !isCurrentUser && !isGroupCreator
        ? _buildDismissibleMember(member, index)
        : buildMemberCard(member);
  }

  Widget _buildDismissibleMember(Map<String, dynamic> member, int index) {
    final name = member['username'] ?? 'User';

    return Dismissible(
      key: Key(member['uid']),
      direction: DismissDirection.endToStart,
      background: _buildDismissBackground(),
      confirmDismiss: (_) async => await _showConfirmationDialog(
          "Remove Member",
          "Are you sure you want to remove $name from the group?",
          "Remove"),
      onDismissed: (_) async {
        await FirebaseFirestore.instance
            .collection('groups')
            .doc(widget.groupData['id'])
            .collection('members')
            .doc(member['uid'])
            .delete();

        await FirebaseFirestore.instance
            .collection('groups')
            .doc(widget.groupData['id'])
            .update({
          'members': FieldValue.arrayRemove([member['uid']])
        });

        setState(() => members.removeAt(index));

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("$name removed from the group")),
        );
      },
      child: buildMemberCard(member),
    );
  }

  Widget _buildDismissBackground() {
    return Container(
      color: Colors.red,
      alignment: Alignment.centerRight,
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: const Icon(Icons.delete, color: Colors.white),
    );
  }

  Future<bool?> _showConfirmationDialog(
      String title, String content, String confirmText) {
    return showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(content),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text("Cancel")),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text(confirmText)),
        ],
      ),
    );
  }

  Widget buildTaskCard(Map<String, dynamic> task) {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    final dueDate = _formatDueDate(task['dueDate']);
    final isAssignedToCurrentUser = task['assignedMember'] == uid;

    return InkWell(
      onTap: () => _navigateToTaskDetails(task),
      child: Container(
        margin: const EdgeInsets.only(bottom: 15),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Text(
                    task['title'],
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                // if (_userRole == 'admin' || isAssignedToCurrentUser)
                //   Checkbox(
                //     value: task['completed'] ?? false,
                //     onChanged: (val) {
                //       task['completed'] = val;
                //       markTaskAsComplete(task);
                //       ScaffoldMessenger.of(context).showSnackBar(
                //         const SnackBar(
                //           content: Text('Task status updated successfully.'),
                //           backgroundColor: Colors.green,
                //         ),
                //       );
                //     },
                //   ),
              ],
            ),
            if ((task['description'] ?? '').toString().isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(task['description']),
              ),
            if (dueDate != null)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  "Due: $dueDate",
                  style: const TextStyle(color: Colors.orange, fontSize: 12),
                ),
              ),
            if (task['hasReward'] == true)
              const Padding(
                padding: EdgeInsets.only(top: 4),
                child: Text("🎁 Has Reward", style: TextStyle(fontSize: 12)),
              ),
            if (task['assignedMember'] != null)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  "Assigned to: ${_getMemberName(task['assignedMember'])}",
                  style: const TextStyle(
                      fontSize: 12, fontStyle: FontStyle.italic),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget buildMemberCard(Map<String, dynamic> member) {
    final isCurrentUser =
        member['uid'] == FirebaseAuth.instance.currentUser?.uid;
    final profileUrl = member['profileImage'];
    final name = member['username'] ?? 'User';
    final initials = name.isNotEmpty ? name[0].toUpperCase() : '?';
    final bgColor =
        Colors.primaries[members.indexOf(member) % Colors.primaries.length];

    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.2),
            blurRadius: 5,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: profileUrl != null ? Colors.transparent : bgColor,
            backgroundImage:
                profileUrl != null ? NetworkImage(profileUrl) : null,
            child: profileUrl == null
                ? Text(initials, style: const TextStyle(color: Colors.white))
                : null,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Text("Role:",
                        style: TextStyle(fontWeight: FontWeight.w500)),
                    const SizedBox(width: 4),
                    Text(member['role']),
                  ],
                ),
              ],
            ),
          ),
          if (_userRole == 'admin' && !isCurrentUser)
            Column(
              children: [
                const Text("Make Admin"),
                Switch(
                  value: member['role'] == 'admin',
                  onChanged: (val) async {
                    final newRole = val ? 'admin' : 'member';
                    await FirebaseFirestore.instance
                        .collection('groups')
                        .doc(widget.groupData['id'])
                        .collection('members')
                        .doc(member['uid'])
                        .update({'role': newRole});
                    setState(() => member['role'] = newRole);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Updated $name to $newRole"),
                        backgroundColor: Colors.green,
                      ),
                    );
                  },
                ),
              ],
            ),
        ],
      ),
    );
  }

  Future<void> markTaskAsComplete(Map<String, dynamic> task) async {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    final taskRef =
        FirebaseFirestore.instance.collection('tasks').doc(task['id']);
    await taskRef.update({'completed': task['completed']});

    if (task['hasReward'] == true && task['assignedMember'] == uid) {
      final reward = Reward(
        userId: uid,
        taskId: task['id'],
        points: 10,
        title: 'Completed "${task['title']}"',
        awardedAt: Timestamp.now(),
          description: task['rewardDescription']
      );

      await FirebaseFirestore.instance
          .collection('rewards')
          .add(reward.toMap());

      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text("🎉 Congrats!"),
          content: Text(
              "You got ${task['rewardDescription'] ?? ''} for completing this task!"),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Awesome!"),
            ),
          ],
        ),
      );
    }
  }

  String _getMemberName(String uid) {
    final member = members.firstWhere((m) => m['uid'] == uid, orElse: () => {});
    return member['username'] ?? uid;
  }
}
