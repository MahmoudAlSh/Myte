import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:myte_1/auth.dart';

import 'navbar.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}
// a blank page that checks if the user is logged in or not. based on login status it takes you to different screens either to sign in and if u signed in it will take you to home page ( dashboard)
class _SplashState extends State<Splash> {
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 500), () {
      if (FirebaseAuth.instance.currentUser != null) {
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => Navbar()), (route) => false);
      } else {
        Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => AuthPage()), (route) => false);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
