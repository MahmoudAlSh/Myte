import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class RewardsPage extends StatefulWidget {
  const RewardsPage({super.key});

  @override
  State<RewardsPage> createState() => _RewardsPageState();
}

class _RewardsPageState extends State<RewardsPage> {
  List<QueryDocumentSnapshot> _rewards = [];
  StreamSubscription? _subscription;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _listenToRewards();
  }

  void _listenToRewards() {
    final uid = FirebaseAuth.instance.currentUser?.uid;
    if (uid == null) return;

    _subscription = FirebaseFirestore.instance
        .collection('rewards')
        .where('userId', isEqualTo: uid)
        .orderBy('awardedAt', descending: true)
        .snapshots()
        .listen((snapshot) {
      setState(() {
        _rewards = snapshot.docs;
        _isLoading = false;
      });
    });
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }

  Icon _getIconForPoints(int points) {
    if (points >= 100) {
      return const Icon(Icons.emoji_events, color: Colors.amber);
    } else if (points >= 50) {
      return const Icon(Icons.star, color: Colors.blueAccent);
    } else {
      return const Icon(Icons.thumb_up, color: Colors.green);
    }
  }

  AppBar _buildAppBar() {
    return AppBar(
      title: const Text(
        "Your Rewards",
        style: TextStyle(color: Colors.black87),
      ),
      backgroundColor: Colors.white,
      elevation: 1,
      centerTitle: true,
      automaticallyImplyLeading: false,
      iconTheme: const IconThemeData(color: Colors.black),
    );
  }

  Widget _buildRewardCard(Map<String, dynamic> data) {
    final points = data['points'] ?? 0;
    final date = (data['awardedAt'] as Timestamp?)?.toDate();

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        leading: _getIconForPoints(points),
        title: Text(
          data['title'] ?? 'Reward',
          style: const TextStyle(fontWeight: FontWeight.w600),
        ),
        subtitle: Text("Description: ${data['description'] ?? ''}"),
        trailing: date != null
            ? Text(
          DateFormat('MMM d, yyyy').format(date),
          style: const TextStyle(fontSize: 12, color: Colors.grey),
        )
            : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _rewards.isEmpty
          ? const Center(
        child: Text(
          "No rewards yet.",
          style: TextStyle(fontSize: 16),
        ),
      )
          : ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _rewards.length,
        itemBuilder: (_, index) {
          final data = _rewards[index].data() as Map<String, dynamic>;
          return _buildRewardCard(data);
        },
      ),
    );
  }
}